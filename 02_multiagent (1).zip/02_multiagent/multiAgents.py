# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
      A reflex agent chooses an action at each choice point by examining
      its alternatives via a state evaluation function.

      The code below is provided as a guide.  You are welcome to change
      it in any way you see fit, so long as you don't touch our method
      headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {North, South, West, East, Stop}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()
        legalMoves.remove(Directions.STOP)

        # Check if there are no legal moves available
        if not legalMoves:
          return Directions.STOP

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"
        if bestScore > 0:
           # Evaluate each legal move
          for action in legalMoves:
            # Generate a successor game state for each move
            successorGameState = gameState.generatePacmanSuccessor(action)
             # Get the new food layout
            newFood = successorGameState.getFood()
            newPos = successorGameState.getPacmanPosition()
            # Set initial food distance to infinity
            foodDist = float("inf")
            # Loop through each food position and calculate the distance to the new Pacman position
            for foodPos in newFood.asList():
                dist = util.manhattanDistance(newPos, foodPos)
                 # If the distance is smaller than the current smallest distance, set the new smallest distance
                if dist < foodDist:
                    foodDist = dist
            # If the closest food is one square away, return that action to eat it       
            if foodDist == 1:
                return action
            
        # If no food is one square away, return the action with the highest index in the legal moves list
        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]
  

        "*** YOUR CODE HERE ***"
        #Get the score of the successor state
        score = successorGameState.getScore()

      
        foodScore = 0
        ghostScore = 0
        foodDistance = float("inf")
        #Calculae the distance to the closest food
        for foodPosition in newFood.asList():
          distance = manhattanDistance(newPos, foodPosition)
          if distance < foodDistance:
            foodDistance = distance

        # Calculate distance to the closest ghost
        ghostDistance = float("inf")
        scaredGhosts = 0
        for ghostState in newGhostStates:
          distance = manhattanDistance(newPos, ghostState.getPosition())
          if distance < ghostDistance:
            ghostDistance = distance
          if ghostState.scaredTimer > 0:
            scaredGhosts += 1

    # Calculate the reciprocal of distance to the closest food pellet and ghost
          if foodDistance == 0:
             foodDistance = 1
          if ghostDistance == 0:
             ghostDistance= 1
             foodScore = 1.0 / foodDistance
          if scaredGhosts > 0:
             ghostScore = 1.0 / ghostDistance
          else:
             ghostScore = -1.0 / ghostDistance

        # Calculate final score and return it 
        finalScore = score + foodScore + ghostScore

        return finalScore
      
             

def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
      Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action from the current gameState using self.depth
          and self.evaluationFunction.

          Here are some method calls that might be useful when implementing minimax.

          gameState.getLegalActions(agentIndex):
            Returns a list of legal actions for an agent
            agentIndex=0 means Pacman, ghosts are >= 1

          gameState.generateSuccessor(agentIndex, action):
            Returns the successor game state after an agent takes an action

          gameState.getNumAgents():
            Returns the total number of agents in the game
        """
        "*** YOUR CODE HERE ***"
        #Create a minimax algorithm to determine the value of the game and to help pacman find his way
        #What this algorithm is trying to do is to minimize the expected utility/score of the ghosts by maximizing pacman's utility so that pacman can win the game
        def minimax(state, agentIndex, depth):
            if any(condition for condition in [state.isWin(), state.isLose(), depth == self.depth]):
               return self.evaluationFunction(state)
            #here we are talking about pacman
            #We are checking if it's pacman, then simply maximize pacman's score
            if agentIndex == 0:
                # Maximize the score for pacman
                score = float("-inf")
                #What are the legal actions that pacman can take in the game?
                #We are iterating through the legal actions for pacman. Note that pacman is when the agentIndex == 0, otherwise we are talking about the ghosts
                for action in state.getLegalActions(agentIndex):
                    #After pacman takes an action, what is the current game state?
                    successor = state.generateSuccessor(agentIndex, action)
                    #the score is determined by finding the maximum between the score and the minimax of the successor 
                    score = max(score, minimax(successor, 1, depth))
                return score
            #The pacman condition is not met and hence we are talking about the ghosts now
            else:
                
                score = float("inf")
                legalActions = state.getLegalActions(agentIndex)
                for legalAction in legalActions:
                    successor = state.generateSuccessor(agentIndex, legalAction)
                  
                    
                    if agentIndex == state.getNumAgents() - 1:
                        # minimize the score for the last ghost
                        score = min(score, minimax(successor, 0, depth + 1))
                    else:
                        #Not the last ghost, minimize the score for the next ghost agent
                        score = min(score, minimax(successor, agentIndex + 1, depth))
                return score
        #Get pacman's legal actions and choose the best action to take
        #legalActions = gameState.getLegalActions(0)
        bestAction = None
        bestValue = float("-inf")
        for legalAction in gameState.getLegalActions(0):
            successor = gameState.generateSuccessor(0, legalAction)
            value = minimax(successor, 1, 0)
            if value > bestValue:
                bestValue = value
                bestAction = legalAction
        return bestAction

 
       
        util.raiseNotDefined()

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
      Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        def maxValue(gameState, depth, agentIndex, alpha, beta):
             # Check if the game state is a win or lose state or if the maximum depth has been reached
            if (gameState.isWin() or gameState.isLose() or depth == self.depth):
                #Here Directions.STOP means that pacman should not take any action at this point
               return self.evaluationFunction(gameState), Directions.STOP

           
            v = float("-inf")
            bestAction = Directions.STOP
            for action in gameState.getLegalActions(agentIndex):
                successor = gameState.generateSuccessor(agentIndex, action)
                result = minValue(successor, depth, agentIndex + 1, alpha, beta)
                successorValue = result[0]


                # If the value of the successor game state is greater than v, update v and bestAction
                if successorValue > v:
                    v = successorValue
                    bestAction = action

                if v > beta:
                    return v, bestAction

                alpha = max(alpha, v)
                
            # Return the value of the current game state and the best action to take
            return v, bestAction

        def minValue(gameState, depth, agentIndex, alpha, beta):
            if (gameState.isWin() or gameState.isLose() or depth == self.depth):
                #Here Directions.STOP means that pacman should not take any action at this point
               return self.evaluationFunction(gameState), Directions.STOP
            value = float("inf")
            bestAction = Directions.STOP
            #Last index
            if agentIndex == gameState.getNumAgents() - 1:
                for action in gameState.getLegalActions(agentIndex):
                    successor = gameState.generateSuccessor(agentIndex, action)
                    successorValue = maxValue(successor, depth + 1, 0, alpha, beta)[0]

                    if successorValue < value:
                        value = successorValue
                        bestAction = action

                    if value < alpha:
                        return value, bestAction

                    beta = min(beta, value)
                    #Not last index
            else:
                #Loop through all legal actions for the current agentIndex
                for action in gameState.getLegalActions(agentIndex):
                    successor = gameState.generateSuccessor(agentIndex, action)
                    successorValue = minValue(successor, depth, agentIndex + 1, alpha, beta)[0]

                    if successorValue < value:
                        value = successorValue
                        bestAction = action

                    if value < alpha:
                        return value, bestAction
                    #Beta will be the minimum of beta and the value determined

                    beta = min(beta, value)

            return value, bestAction

        # Start the alpha beta searching
        # Compute the maximum value and best action for the root node by calling the maxValue function on the root node
        
        return maxValue(gameState, 0, 0, float("-inf"), float("inf"))[1]
        util.raiseNotDefined()

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
          Returns the expectimax action using self.depth and self.evaluationFunction

          All ghosts should be modeled as choosing uniformly at random from their
          legal moves.
        """
        "*** YOUR CODE HERE ***"
        def maximize(state, agentIndex, depth):
            if any(condition for condition in [state.isWin(), state.isLose(), depth == self.depth]):
               return self.evaluationFunction(state)
            value = float("-inf")
            value = max(expValue(state.generateSuccessor(agentIndex, action), agentIndex + 1, depth) for action in state.getLegalActions(agentIndex))
            return max(value, float("-inf"))

        def expValue(state, agentIndex, depth):
            if any(condition for condition in [state.isWin(), state.isLose(), depth == self.depth]):
             return self.evaluationFunction(state)
            # What are the actions that can be taken in the current game state?
            value = 0
            actions = state.getLegalActions(agentIndex)
            #This is the probability of taking an action, we are using 1.0 because probability adds up to 100 and 1.0 is a float form of 1
            probabilityOfAction = 1.0 / len(actions)
            #For every legal action in all the legal actions
            for action in actions:
                successorState = state.generateSuccessor(agentIndex, action)
                if agentIndex == state.getNumAgents() - 1:
                    #If we are at the last agent, the value which was 0 becomes the maximized value of the next state, first agent(pacman) and the depth + 1
                    value += maximize(successorState, 0, depth + 1)
                else:
                    value += expValue(successorState, agentIndex + 1, depth)
            return value * probabilityOfAction

        legalActions = gameState.getLegalActions(0)
        successors = [gameState.generateSuccessor(0, action) for action in legalActions]
        scores = [expValue(successor, 1, 0) for successor in successors]
        #Here we are picking the highest score cause it's the best score
        bestScore = max(scores)
        bestIndices = list(i for i, score in enumerate(scores) if score == bestScore)
        #Let us get a random integer between 0 and the length of bestIndices - 1
        chosenIndex = bestIndices[random.randint(0, len(bestIndices)-1)]
        return legalActions[chosenIndex]
        util.raiseNotDefined()

def betterEvaluationFunction(currentGameState):
    """
      Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
      evaluation function (question 5).

      DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    #Let us first initialize what we are going to need later
    foodGrid = currentGameState.getFood()
    currentGhostStates = currentGameState.getGhostStates()
   
    # Here I am setting the scared timers of the new ghost states using map() and lambda.
    # This creates a new list with the scared timers of each ghost state.
    newScaredTimes = list(map(lambda ghostState: ghostState.scaredTimer, currentGhostStates))

    # The distance to the closest food
    closestFoodDistance = float("inf")
    #Create an empty list to store the manhattan distance being calculated
    foodDistancesGrid = []
    for food in foodGrid.asList():
      distance = manhattanDistance(currentGameState.getPacmanPosition(), food)
      foodDistancesGrid.append(distance)
     
    # Only calculate closest distance if foodDistances is not empty
    if len(foodDistancesGrid) > 0:  
        closestFoodDistance = min(foodDistancesGrid)

    # Here we are calculating the distance to the closest ghost using the manhattan distance
    for ghost in currentGhostStates:
        #The distances of the ghosts
     ghostDistances = [manhattanDistance(currentGameState.getPacmanPosition(), ghost.getPosition())]
     closestGhostDistance = min(ghostDistances)

    # Pacman should be able to check if a specific ghost is close or far to him and if that ghost is scared or not. 
    #Here we are saying, if the ghost is near/ too close to pacman and it's not a scared ghost, then pacman should not take this action
    if newScaredTimes[0] == 0:
      if closestGhostDistance < 2:
        return -float("inf")

    # Calculate the score of the successor state
    successorStateScore = currentGameState.getScore()

    # The weight will be determined based on the remaining food
    remainingFood = sum(1 for row in foodGrid for cell in row if cell)
    if remainingFood > 0:
      foodWeight = 1.0 / remainingFood
    else:
      foodWeight = 0

    # Calculate the weight of the closest food pellet and closest ghost
    closestFoodWeight = 0 if closestFoodDistance == 0 else 1.0 / closestFoodDistance
    closestGhostWeight = 0 if closestGhostDistance == 0 else 1.0 / closestGhostDistance


    # Calculate the final score being evaluated by the algorithm
    finalScore = successorStateScore
    finalScore += 10 * closestFoodWeight
    finalScore -= 10 * closestGhostWeight
    finalScore += 100 * foodWeight

    return finalScore
    util.raiseNotDefined()

# Abbreviation
better = betterEvaluationFunction

